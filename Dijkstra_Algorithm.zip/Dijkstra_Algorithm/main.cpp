#include <iostream>
#include <fstream>
#include "graph.h"
#include "map.h"
#include <sstream> 

int main(int argc, char *argv[]) {
    Graph graph;
    /*
    ifstream cityFile("city.txt");
    if(is_empty(cityFile)) {
        cout << "Error opening city file." << endl;
    }

    unordered_map<string, City> cityMap;
    ifstream roadFile("road.txt");
    if(!roadFile.isEmpty()) {
        cout << "Error opening road file." << endl;
    }*/

    // Display City info
    cout << "Author: Justinas Janovskis, Daniel Cordero, and Diego Roque" << endl;
    cout << "Date: 12/01/2023" << endl;
    cout << "Course: CS311 (Data structures and Algorithms)" << endl;
    cout << "Description : Program to find the shortest route between cities" << endl;
    cout << "----------------------------------------------------------------" << endl;
    

    //Reading inputs from file
    //Cities
    vector<City> cities;
    string a;               //String to be translated
    ifstream fin;           //File stream
	fin.open("city.txt");   //Open the file to be read
    int count = 0;

	int cityID;
    string cityCode;
	string cityName;
	int population;
    int elevation;
	vector<string> parts;
    count =0;
	//Get the next line
	while(getline(fin, a))
	{
		//istringstream grabs all parts of the current line of the file
		istringstream str(a);
		while (str)
		{
			// cityName will be used to take current word and add it to a vector, will later be changed
			str >> cityName;
			parts.push_back(cityName);      //Pushing back Current word
        }
        count++;
		cityID = stoi(parts[0]);     //string to int for city ID
        cityCode = parts[1];         //parts[2] hold cityCode
        cityName = parts[2];         //parts[3] holds cityName
        population = stoi(parts[3]); //string to int for population
        elevation = stoi(parts[4]);  //string to int for elevation

        

		//Finally insert the City
            City c(cityID, cityCode, cityName, population, elevation);  //Create the city
		    cities.push_back(c);    //Move the city to the our cities list
		parts.clear();
	}
	
	fin.close();    //Close the file



    //Determining of the inputs are valid inputs or not and getting city numbers
    bool first = false;
    string f = argv[1];
    int firstCity;
    bool second = false;
    string s = argv[2];
    int secondCity;
    string firstCityName;
    string secondCityName;
    for(int i=0; i < static_cast<int>(sizeof(cities)); i++)
    {
        if(f.compare(cities[i].cityCode) == 0)
        {
            firstCity = i;
            first = true;
            firstCityName = cities[i].cityName;
        }
        if(s.compare(cities[i].cityCode) == 0)
        {
            secondCity = i;
            second = true;
            secondCityName = cities[i].cityName;
        }
    }

    if(!first || !second)
    {
        cout << "Invalid City Code: ";
        if(!first) 
        {
            cout << argv[1] << " ";
        }
        if(!second) 
        {
            cout << argv[2] << " ";
        }
        cout << endl;
        exit(0);
    }

    //Get all the vertices
    vector<int> added;
    for(int i=0; i < count; i++) {         //loop through and convert each city to a vertex and push to graph
            Vertex v(cities[i].cityID, cities[i].cityCode);
            graph.addVertex(v);
    }

    //Add all the edges
    vector<Edge> edges;
	fin.open("road.txt");   //Open the file to be read
    count = 0;
    vector<int> items;
    while(getline(fin, a))
	{
		//istringstream grabs all parts of the current line of the file
		istringstream str(a);
		while (str)
		{
			// cityName will be used to take current word and add it to a vector, will later be changed
			str >> cityName;
			items.push_back(stoi(cityName));      //Pushing back Current word
        }
        count ++;
            Edge e (items[0], items[1], items[2]);  //Create the Edge
		    edges.push_back(e);    //Move the city to the our cities list
		items.clear();
	}
	
	fin.close();    //Close the file


    //Add all the Edges to the graph
    for(int i=0; i < count; i++) {         //loop through and convert each city to a vertex and push to graph            Vertex v(cities[i].cityID, cities[i].cityCode);
            graph.addDirectedEdge(edges[i].from_vertex, edges[i].to_vertex, edges[i].weight);
    }

    vector<int> cityNums;

    //Case of the same city
    cout << "The distance between "<< firstCityName << " and " << secondCityName << " is ";
    if(secondCityName.compare(firstCityName) == 0)
    {
        cout << "0" << endl;
        exit(0);
    }
    int pathNum=graph.shortestPath(firstCity, secondCity, cityNums);     //Testing the shortestPath algorithm

    //Path doesn't exist
    if(pathNum < 0)
    {
        cout << endl << "No route from " << firstCityName << " to " << secondCityName << "." << endl;
        exit(0);
    }

    //Print out all the cities in the path
    for(int i=0; i<pathNum; i++)
    {
        cout << cities[cityNums[i]].cityName;
        if(i < pathNum-1) {
            cout  << "->";
        }
    }
    cout << endl;
    return 0;
}
