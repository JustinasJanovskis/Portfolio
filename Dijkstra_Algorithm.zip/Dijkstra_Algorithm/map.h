#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include "graph.h"
using namespace std;

class City {
public:
    int cityID;
    string cityCode;
    string cityName;
    int population;
    int elevation;

    //Default constructor
    City(){
        cityID = 0;
        cityCode = "";
        cityName = "";
        population = 0;
        elevation = 0;
    }

    City(int id, string code, string name, int pop, int elev) : cityID(id), cityCode(code), cityName(name), population(pop), elevation(elev) {}
};



// Road class
class Road {
public:
    string fromCity;
    string toCity;
    int distance;

    Road(string from, string to, int dist) : fromCity(from), toCity(to), distance(dist) {}
};