#include "graph.h"
#include <limits>

using namespace std;

// @brief Construct a Graph with the given number of vertices.
// @param nV The number of vertices in the graph.
Graph::Graph(int nV)
{
    //loop will add vertex until it the amount equals nV
    for(int i = 0; i < nV; i++)
    {
        Vertex newV;            //initialize new vertex
        addVertex(newV);        //call function to add vertex
    }
}

// @brief destructor
Graph::~Graph()            
{
    //no need to create a destructor since nothing is createing dynamically(using the 'new' keyword)
}

// @brief add a vertex to the graph
void Graph::addVertex(Vertex v)
{
    this->numVerts = this->numVerts + 1;       //update the number of vertices
    vertices.push_back(v);                     //push new vertex onto vector
    v.id = vertices.size() - 1;                //assign vertex id
    vector<Edge> e;                            //create new vector/list
    adjList.push_back(e);                      //push new vector/list onto adjList
}

// @brief add a directed edge v1->v2 to the graph
void Graph::addDirectedEdge(int v1, int v2, float weight)
{
    bool checkForEdge = false;                      //bool to check if edge exists already
    
    for(int i = 0; i < adjList[v1].size(); i++)     //iterate all adjacent vertices of vertex
    {
        if(adjList[v1].at(i).to_vertex == v2)       //checking if adjacent vertex matches vertex2 in parameter
        {
            if(adjList[v1].at(i).weight == 1.0f)    //checking if adjacent vertex has an existing edge 
                checkForEdge = true;                //bool switches to true if there is an existing edge
        }
    }
    
    if(checkForEdge)                                //run statement if there is an existing edge
        std::cout << "Vertex already has directed edge";

    //add edge if there isn't an existing one already
    else    
    {
        Edge newE;                                  //initialize new edge
        newE.from_vertex = v1;                      //assign newEdge.from_vertex to vertex1
        newE.to_vertex = v2;                        //assign newEdge.to_vertex to vertex2
        newE.weight = weight;                       //assign newEdge.weight to weight
        adjList[v1].push_back(newE);                //insert new edge to connect vertex1 to vertex2  
    }
}

// @brief add an undirected edge to the graph
void Graph::addUndirectedEdge(int v1, int v2, float weight) 
{
    //
    addDirectedEdge(v1, v2, weight);                //call function to add direct edge; vertex1->vertex2         
    addDirectedEdge(v2, v1, weight);                //call function to add direct edge; vertex1<-vertex2
}

// @brief the number of outgoing edges from a vertex
int Graph::outDegree(int v)
{
    int outDegree = adjList[v].size();             //numOfEdges = Vertices - 1 (Size of list of that index minus 1)
    return outDegree;                              //return the outDegree of the vertice in the argument
}

// @brief depth first search from vertex v
vector<int> Graph::DepthFirstSearch(int v)
{
    // Add the vertex ID to a vector when it is visited
    vector<int> vertex;                            //initialize stack              
    vector<bool> visited(numVerts, false);         //vector that sets true or false for visitied vertices
    vector<int> visitedList;                       //vector that pushes vertices that have been visited

    vertex.push_back(v);                           //insert starting vertex to stack
    while(!vertex.empty())                         //DFS will be complete once stack is empty
    {
        int cur = vertex.back();                   //set currentVertex to the top of the stack
        vertex.pop_back();                         //pop off vertex from the stack

        if(visited[cur] == false)                  //if currentVertex has not been visited, mark it as visited
        {
            visited[cur] = true;                   //mark currentVertex as visited
            visitedList.push_back(cur);            //push currentVertex to the visitedList

          //will iterate through all the adjacent vertices of the currentVertex
          for(int i = adjList[cur].size() - 1; i >= 0; i--) 
          {
               int adj = adjList[cur][i].to_vertex;     //assign adj to the adjacent vertex
               vertex.push_back(adj);                   //insert adjacent vertex to the stack
          }
        }
    }

    return visitedList;                                 //return order of vertices that have been visited
}

// @brief breadth first search from a vertex
vector<int> Graph::BreadthFirstSearch(int v)    
{
    // Add the vertex ID to a vector when it is visited
    queue<int> q;                                   //discovered, but not yet visited                                
    vector<bool> discovered(numVerts, false);       //first encounters a vertex, being discovered
    vector<int> visitedList;                        //vector for visited vertices
    
    q.push(v);                                      //enqueue start index to frontierqueue
    discovered[v] = true;                           //start index is discovered, set it to true
    while(!q.empty())
    {
        int cur = q.front();                        //set cur to first value of frontierqueue
        q.pop();                                    //pop value for frontierqueue
        visitedList.push_back(cur);                 //add first value of frontierqueue to visitedList

        //loop will go through all adjacent vertexes of current vertex
        for(int i = 0; i < adjList[cur].size(); i++)       
        {
            int adj = adjList[cur][i].to_vertex;     //setting adj to adjacent vertex of current vertex
            //if adj hasn't been discovered, push adj to frontier queue and set adj to be discovered(set to true)
            if(discovered[adj] == false)    
            {
                q.push(adj);            
                discovered[adj] = true;
            }
        }
    }

    return visitedList;                             //return order of vertices that have been visited
}

//Using Dijkstra's Algorithm to find the shortest path
vector<std::pair<float, int>> Graph::Dijkstra(vector<std::pair<float, int>> &vertex, int v)
{
    //vertex[distance, vertex.id]

    priority_queue<std::pair<float, int>> unVisited;                                 //Vertices in the queue are unvisted
    float infinity = std::numeric_limits<float>::infinity();  //float is assigned to infinity
    for(int i = 0; i < vertices.size(); i++)
    {
        vertex.push_back(std::make_pair(infinity, -1));   //each index is [infinity, null]
        
    }

    unVisited.push(std::make_pair(0.0f, v));
    vertex[v].first = 0.0f;                               //set starting vertex's distance to 0
    
    while(!unVisited.empty())                             //while queue is not empty
    {
        int cur = unVisited.top().second;                      //set current_vertex to front value of queue
        unVisited.pop();                                  //pop off front value from queue

        for(int i = 0; i < adjList[cur].size(); i++)         //for each adj_vertex to current_vertex
        {
            float edgeWeight = adjList[cur][i].weight;  //weight of edge from current_vertex to adj_vertex
            float altPathDistance = vertex[cur].first + edgeWeight;   //current_vertex + adj_vertex 

            /*if shorter path from current_vertex to adj_vertex is found
              udpate adj_vertex distance and its predecessor            */
            if(altPathDistance < vertex[adjList[cur][i].to_vertex].first)   
            {
                vertex[adjList[cur][i].to_vertex].first = altPathDistance;  
                vertex[adjList[cur][i].to_vertex].second = cur;
                unVisited.push(std::make_pair(altPathDistance, adjList[cur][i].to_vertex));
            }
        }
    }
    
    return vertex;  //return updated [distance, vertex.id] of all indexes of the vector
}

/** 
 * @brief Will print out the distance of shortest path from vertex1 to vertex2 along
 * with the path from vertex1 to vertex2 
 */
int Graph::shortestPath(int v1, int v2, vector<int> &cityNums) 
{
     vector<std::pair<float, int>> vertex;          //initialize vector that will hold [distance, vertex.id]
     Dijkstra(vertex, v1);                          //call function
     int h;
     //if the vertex2 distance is equal to infinity, no route exists between the two vertices
     if(vertex[v2].first == std::numeric_limits<float>::infinity())
     {
        return -1;
     }

     else {
        vector<int> path;              //vector/stack that will hold the path from vertex1 to vertex2
        int cur = v2;                  //int will act as a pointer for the predecessor of each vertex

        /*Will iterate backwards from vertex2 until it reaches vertex1 using the predecessor (vertex[index].second)
         to assign to cur, "the pointer", and pushing cur onto the stack/vector.
         Loop will stop once it reaches vertex1
        */
        while(cur != -1)
        {
            path.push_back(cur); 
            cur = vertex[cur].second;
        }

        std::cout << vertex[v2].first << endl;
        std::cout << "through the route: ";
        h = 0;
        for(int i = path.size() - 1; i >= 0; i--)
        {
            cityNums.push_back(path[i]);
            h++;
            path.pop_back();
            
        }
    }
    return h;
}

/**
 * @brief Check if the graph has cycles
 * @return true if the graph has cycles
 */
bool Graph::checkCycle()
{

    // Assume an undirected graph
    return false;
}

// @brief print the graph
void Graph::printGraph()
{
    std::cout << "Graph:" << endl;
    for (int i = 0; i < numVerts; i++)
    {
        std::cout << i << ": ";
        for(auto j = adjList[i].begin(); j != adjList[i].end(); ++j)
        {
            std::cout << (*j).to_vertex << " " ;
        }
        std::cout << endl;
    }
    std::cout << endl;
}

