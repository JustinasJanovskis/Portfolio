.cpu cortex-a53
.fpu neon-fp-armv8

.data

filename:   .asciz  "dictionary.txt"
rw:         .asciz  "r"
hangman:    .asciz  "-------"
guessed:    .asciz  "++++++++++++++++++++++++++"


@ for debug
output:   .asciz  "%s\n"
debug_print: .asciz "%c\n"
game_is_over:  .asciz  "The game is over!!!\n"
game_is_not_over:  .asciz  "The game is NOT over!!!\n"
outp1: .asciz "Enter your guess: "

.text
.align 2
.global main
.type main, %function

main:
     push {fp, lr}
     add fp, sp, #4

     mov r0, #0
     bl time
     bl srand

     @ key
     @ fileptr - fp - 8
     @ keyword - fp - 12
     @ guessed - fp - 16
     @ hangman - fp - 20
     @ play    - fp - 24
     @ num guesses - fp - 28
     @ counter

     sub sp, sp, #28   @ allocate 7 memory locations on the stack

     @ Do some initialization: hangman = "-------"
     @ initialize number of guesses left = 7
     mov r0, #7
     str r0, [fp, #-28]
     
     @ init hangman
     ldr r0, =hangman
     bl strlen
     add r0, r0, #1
     bl malloc
     str r0, [fp, #-20]
     @ strcpy(hangman, "-------")
     ldr r1, =hangman
     ldr r0, [fp, #-20]
     bl strcpy

     @ init guessed
     mov r0, #27
     bl malloc
     str r0, [fp, #-16]
     @ strcpy(guessed, "++++...");
     ldr r0, [fp, #-16]
     ldr r1, =guessed
     bl strcpy

     @ Open file for reading

     ldr r0, =filename
     ldr r1, =rw
     bl fopen
     str r0, [fp, #-8]

     @ get_guess(fileptr, address of keyword, address play)
     ldr r0, [fp, #-8]
     sub r1, fp, #12
     sub r2, fp, #24

     bl get_guess

     @ close the file
     ldr r0, [fp, #-8]
     bl fclose

     @skip every other to remove error
     mov r6, #90
     str r6, [fp, #-32]
     @---------------------------------
	ldr r1, [fp, #-24]
	ldr r0, =output
	bl printf

	ldr r0, =outp1
	bl printf
     the_game_loop:

     @ get char
	mov r0, #0
mov r1, #0
mov r2, #0
mov r3, #0
	ldrb r4, [fp, #-32]
	bl ask_guess
     @bl printf
	
	@mov r4, r1
	@str r4, [fp, #-32]
	@cmp r4, #10
	@beq branch


	@ MY CODE
	@Current version, subtract one from number of guesses
     ldr r0, [fp, #-24]    @ play
     ldr r1, [fp, #-16]    @ guessed
     ldr r2, [fp, #-12]    @ Correct word
     ldr r3, [fp, #-28]    @ number guesses left
	bl checkLetter
     str r0, [fp, #-24]
     str r1, [fp, #-16]
     str r2, [fp, #-12]
     str r3, [fp, #-28]
	bl print_status
     @ check game over
     ldr r0, [fp, #-24]
     ldr r1, [fp, #-28]
     bl game_over
     cmp r0, #1
     beq end_program
	
	branch:
	@ldr r4, [fp, #-32]
	@cmp r4, #10
	@beq add
     b the_game_loop
	

	@add:
	@mov r0, #1
	@str r0, [fp, #-32]
	@b the_game_loop
	
     end_program:
     
     @----------------------------------

     @ free memory
     @ldr r0, [fp, #-12]
     @bl free
     @ldr r0, [fp, #-16]
     @bl free
     @ldr r0, [fp, #-20]
     @bl free
     @ldr r0, [fp, #-24]
     @bl free

     sub sp, fp, #4
     pop {fp, pc}
