
.cpu cortex-a53
.fpu neon-fp-armv8

.data


.text
.align 2
.global mod
.type mod, %function


mod:

   push {fp, lr}
   add fp, sp, #4

   @ r0 = c, r1 = d
   udiv r4, r0, r1   @ r4 = r0 / r1 = c / d
   mul r4, r4, r1    @ r4 = r4 * r1 = r4 = r4 * d
   sub r4, r0, r4    @ r4 = r0 - r4 = c - d

   mov r0, r4


   sub sp, fp, #4
   pop {fp, pc}
