.cpu cortex-a53
.fpu neon-fp-armv8
#include <stdio.h>
#include <string.h>

.data

guess_inp:  .asciz "%c"
guess_inp2: .asciz "Enter your guess: "

outp1: .asciz "%d\n"
.text
.align 2
.global ask_guess
.type ask_guess, %function

ask_guess:
     push {fp, lr}
     add fp, sp, #4

   
  @   ldr r0, =guess_inp2
  @      bl printf
	

    @ scanf("%c", sp)
     sub sp, sp, #4
     mov r1, sp
     ldr r0, =guess_inp
     bl scanf

		

     ldrb r0, [sp]
	mov r0, #0
     ldrb r0, [sp, #1]
     sub sp, fp, #4
     pop {fp, pc}
 