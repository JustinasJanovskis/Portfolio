.cpu cortex-a53
.fpu neon-fp-armv8

.data
inp_get:   .asciz  "%s"
inp_get_int:  .asciz  "%d"

.text
.align 2
.global get_guess
.type get_guess, %function


get_guess:
     push {fp, lr}
     add fp, sp,#4

     @ r0 = fileptr, r1 = addr keyword, r2 = addr of play

     push {r0}  @ fp-8
     push {r1}  @ fp-12
     push {r2}  @ fp-16

     ldr r1, =inp_get_int
     sub sp, sp, #4
     mov r2, sp
     bl fscanf

     bl rand
     ldr r1, [sp]
     bl mod
     push {r0}   @ rand #, fp-24

     mov r0, #80
     bl malloc
     push {r0}   @ temp, fp-28

     mov r10, #0

     guess_loop:
         ldr r3, [fp, #-24]  @ random # between 0 and n
         cmp r10, r3
         bge end_guess_loop
         @fscanf(fp, "%s", temp)

         ldr r0, [fp, #-8]  @ fileptr
         ldr r1, =inp_get   @ "%s"
         ldr r2, [fp, #-28] @ address of temp
         bl fscanf

         add r10, r10, #1
         b guess_loop

     end_guess_loop:

     ldr r0, [fp, #-8]  @ fileptr
     ldr r1, =inp_get   @ "%s"
     ldr r2, [fp, #-28] @ address of temp
     bl fscanf

     ldr r0, [fp, #-28]  @ loading temp into r0
     bl strlen
 
     add r0, r0, #1
     bl malloc
     ldr r1, [fp, #-12]
     str r0, [r1]       @ store the address of the keyword
                        @ into the stack location back in main

     @ copy temp into keyword
     ldr r0, [fp, #-12]  @ keyword
     ldr r0, [r0]
     ldr r1, [fp, #-28]  @ temp

     bl strcpy

     @ set play to "-----"
     ldr r0, [fp, #-12]
     ldr r0, [r0]
     bl strlen
     add r0, r0, #1
     bl malloc
     ldr r1, [fp, #-16]
     str r0, [r1]

     @ de-allocate memory from temp
     ldr r0, [fp, #-28]
     bl free
 
     @ copy keyword into play
     ldr r0, [fp, #-16]    @ play
     ldr r0, [r0]
     ldr r1, [fp, #-12]    @ keyword
     ldr r1, [r1]
     bl strcpy

     @ hyphenate play
     mov r10, #0

     guess_loop2:
          ldr r0, [fp, #-12]
          ldr r0, [r0]
          bl strlen
          cmp r10, r0

          bge end_guess_loop2

          ldr r0, [fp, #-16]
          ldr r0, [r0]
          mov r1, #'-
          strb r1, [r0, r10]
          add r10, r10, #1
          b guess_loop2

     end_guess_loop2:

     sub sp, fp, #4
     pop {fp, pc}
