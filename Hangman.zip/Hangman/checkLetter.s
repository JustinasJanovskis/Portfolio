.cpu cortex-a72
.fpu neon-fp-armv8
.syntax unified

.data
outp1: .asciz "%s\n"
outp2: .asciz "%d\n"
.text
.align 2
.global checkLetter
.type checkLetter, %function
checkLetter:
push {fp, lr}
add fp, sp, #4
mov r7, r0
mov r8, r1
mov r9, r2
mov r10, r3

@check if the letter is in the word
mov r4, r2   @playing field
ldrb r5, [fp, -8]   @guessed letter
cmp r5, #10
beq stop
mov r6, #0
whileloop:
ldrb r3, [r4]
cmp r3, 0
beq end_whileloop

@ compare the guessed letteer with the current letter
ldrb r1, [r4]
cmp r1, r5
bne incorrect
mov r6, #1

@ move the letter into the correct position
mov r0, r4
sub r0, r0, r9
strb r1, [r7, r0]
incorrect:

@ldr r0, =outp1
@mov r1, r1
@bl printf
@ldr r0, =outp1
@mov r1, r5
@bl printf

@add letter to the list of guessed letters
mov r0, r5
sub r0, r0, #'a
strb r5, [r8, r0]

add r4, r4, 1
b whileloop

end_whileloop:

cmp r6, #0
bgt skip
sub r10, r10, #1
skip:
stop:
mov r0, r7
mov r1, r8
mov r2, r9
mov r3, r10

sub sp, fp, #4
pop {fp, pc}

