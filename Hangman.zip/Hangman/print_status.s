.cpu cortex-a53
.fpu neon-fp-armv8

.data

print_status_outp_play:   .asciz  "Play: %s\n"
print_status_outp_guessed:   .asciz  "Letters guessed: %s\n"
print_status_outp_hangman:   .asciz  "Plays left: %s\n"
print_status_outp2:  .asciz  "Lives left: %d\n\n"

.text
.align 2
.global print_status
.type print_status, %function


print_status:

     push {fp, lr}
     add fp, sp, #4

     @ r0 = play; r1 = letters guessed; r2 = hangman; r3 = guesses left

     @ save data onto stack
     mov r7, r0  @ fp - 8   play
     mov r8, r1  @ fp - 12  guessed
     mov r9, r2 @ fp - 16  hangman
     mov r10, r3  @ fp - 20  number of guesses left
	
	@skip for enter
	ldrb r5, [fp, #-8]
	cmp r5, #10
	beq stopping

     ldr r0, =print_status_outp_play
     mov r1, r7
     bl printf

     ldr r0, =print_status_outp_guessed
     mov r1, r8
     bl printf
     
     ldr r0, =print_status_outp2
     mov r1, r10
     bl printf
	
	stopping:
	mov r0, r7
	mov r1, r8
	mov r2, r9
	mov r3, r10
     sub sp, fp, #4
     pop {fp, pc}
