.cpu cortex-a53
.fpu neon-fp-armv8

.data
outp2: .asciz "Enter your guess: "

.text
.align 2
.global game_over
.type game_over, %function


game_over:

     push {fp, lr}
     add fp, sp, #4

     @ r0 = play; r1 = number of guesses left
     @ return 0 if not game over, 1 if game is over
	ldrb r5, [fp, #-8]
	cmp r5, #10
	beq stop
     push {r0}   @ fp - 8
     push {r1}

     mov r0, #1

     cmp r1, #0
     ble is_game_over

     @ check the array play for '-'
     ldr r0, [fp, #-8]
     bl strlen
     mov r3, r0  @ r3 = length of play string

     ldr r2, [fp, #-8]
     
     mov r0, #1   @ assume game is over until a '-' is found

     mov r10, #0
     game_over_loop:
         cmp r10, r3
         bge is_game_over

         ldrb r9, [r2, r10]
         cmp r9, #'-
         beq end_game_over_loop

         add r10, r10, #1
         b game_over_loop
         
     end_game_over_loop:
     mov r0, #0
	
	mov r7, r0
	ldr r0, =outp2
	bl printf
	mov r0, r7
     is_game_over:
	stop:
     sub sp, fp, #4
     pop {fp, pc}
