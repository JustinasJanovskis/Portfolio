@checking if the game is over or not
.cpu cortex-a72
.fpu neon-fp-armv8

.data
outp1: .asciz "Go Fishing because Game Over\n"
outp2: .asciz "You win!\n"
outp3: .asciz "Unfortunately, the Computer wins.\n Better luck next time!\n"
outp4: .asciz "It's a tie!\nYou're as good as the computer!\n"
.text
.align 2
.global game_over
.type game_over, %function
game_over:
push {fp, lr}
add fp, sp, #4

@Procedures:
@1. Check if deck is empty
@2. Check if hands are empty
@3. Check if total pairs is 26
@4. If game is over, then output winner with more pairs

mov r7, #0 	@if r7 becomes 1, then the game isn't over
mov r8, r0	@deck
mov r9, r1	@human hand
mov r10, r2	@computer hand

@Check if deck is empty
mov r4, #0
mov r5, #0
mov r6, #0
check_empty_deck_loop:
cmp r4, #52 	@r4 = 52
beq end_check_empty_deck_loop

@check if the current card is a 0
ldr r6, [r8, r5]
add r5, r5, #4

cmp r6, #0
beq check_empty_deck_skip
mov r7, #1

check_empty_deck_skip:
add r4, r4, #1	@r4 = r4 + 1
b check_empty_deck_loop
end_check_empty_deck_loop:

@checking human hand for empty
mov r4, #0
mov r5, #0
mov r6, #0
check_empty_human_hand_loop:
cmp r4, #47     @r4 = 47
beq end_check_empty_human_hand_loop

@check if the current card is a 0
ldr r6, [r9, r5]
add r5, r5, #4

cmp r6, #0
beq check_empty_human_hand_skip
mov r7, #1

check_empty_human_hand_skip:
add r4, r4, #1  @r4 = r4 + 1
b check_empty_human_hand_loop
end_check_empty_human_hand_loop:

@checking computer hand for emptiness
mov r4, #0
mov r5, #0
mov r6, #0
check_empty_computer_hand_loop:
cmp r4, #47 @r4 = 47
beq end_check_empty_computer_hand_loop

ldr r6, [r10, r5]
add r5, r5, #4

cmp r6, #0
beq check_empty_computer_hand_skip
mov r7, #1
check_empty_computer_hand_skip:
add r4, r4, #1
b check_empty_computer_hand_loop
end_check_empty_computer_hand_loop:

@Check if the number of pairs is 26
sub fp, sp, #4
ldr r0, [fp, #-4]
ldr r1, [fp, #-8]
add fp, sp, #4

add r0, r0, r1 	@r0 = r0 + r1
cmp r0, #26
bne skip
mov r7, #1
skip:
mov r0, r7
@
@cmp r7, #0
@bne end
@game over
@ldr r0, =outp1
@bl printf
@
@sub fp, sp, #4
@ldr r0, [fp, #-4]
@ldr r1, [fp, #-8]
@add fp, sp, #4
@
@cmp r0, r1
@bgt human_wins
@cmp r0, r1
@blt computer_wins
@cmp r0, r1
@beq tie
@ the human won
@human_wins:
@ldr r0, = outp2
@bl printf
@b end
@computer_wins:
@ldr r0, =outp3
@bl printf
@b end
@tie:
@ldr r0, =outp4
@bl printf
@b end
@end:
@mov r0, r7
sub sp, fp, #4
pop {fp, pc}
