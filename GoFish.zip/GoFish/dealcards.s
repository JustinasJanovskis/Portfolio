.cpu cortex-a72
.fpu neon-fp-armv8

.data
outp1: .asciz "Dealing the Cards!\n"
outp2: .asciz "Dealed Card: %d\n"
.text
.align 2
.global dealcards
.type dealcards, %function
dealcards:

push {fp, lr}
add fp, sp, #4

@Set r10 to r0 for parameter
mov r8, r0 @deck
mov r9, r1 @player hand
mov r10, r2 @computer hand
@output dealing cards
ldr r0, =outp1
bl printf

mov r4, #0
loop:
@for loop r4 =i, loop 10 times
cmp r4, #10
beq end

@printing out the current card
@ldr r0, =outp2
@ldr r1, [r8]
@bl printf
add r8, r8, #4
@add r4+1 for next iteration
ldr r1, [r8, #-4]
@first 5 numbers go to player hand
cmp r4, #5
blt human_hand
b computer_hand

@current card to human hand
human_hand:
str r1, [r9]
add r9, r9, #4
b skip_comp_hand

@current card to computer hand
computer_hand:
str r1, [r10]
add r10, r10, #4
skip_comp_hand:
mov r6, #0
str r6, [r8, #-4]
add r4, r4, #1
b loop
end:



sub sp, fp, #4
pop {fp, pc}
