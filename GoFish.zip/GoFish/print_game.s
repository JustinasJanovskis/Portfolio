@print end result of game over
.cpu cortex-a72
.fpu neon-fp-armv8

.data
outp1:	.asciz "The game has been decided!\n"
outp2:	.asciz "You are victorious in your efforts\nCongratulations on beating a computer\n"
outp3:  .asciz "Unfortunately your legacy has ended\nYou Lose.\n"
outp4:  .asciz "It's a tie!\nYou are as good as the computer!\n"

.text
.align 2
.global print_game
.type print_game, %function
print_game:
push {fp, lr}
add fp, sp, #4

@ r9 = r0 | r10 = r1
mov r9, r0
mov r10, r1

ldr r0, =outp1
bl printf

cmp r9, r10
bgt win
cmp r9, r10
blt lose
cmp r9, r10
beq tie
win:
ldr r0, =outp2
bl printf
b end

lose:
ldr r0, =outp3
bl printf
b end

tie:
ldr r0,=outp4
bl printf
b end

end:

sub sp, fp, #4
pop {fp, pc}
