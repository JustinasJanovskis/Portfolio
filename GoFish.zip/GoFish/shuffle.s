.cpu cortex-a53
.fpu neon-fp-armv8

.data


.text
.align 2
.global shuffle
.type shuffle, %function


shuffle:
    push {fp, lr}
    add fp, sp, #4

    @ r0 = array address of deck
    push {r0}

    mov r0, #0
    bl time
    bl srand

    @ allocate memory for 13
    sub sp, sp, #52   @ 13*4 bytes

    mov r10, #0
    shuffle_init:
       cmp r10, #13
       bge end_shuffle_init

       mov r1, r10, LSL #2
       mov r2, #0
       str r2, [sp, r1]
       add r10, r10, #1
       b shuffle_init

    end_shuffle_init:

    @ shuffle the deck
    mov r10, #52
    shuffle_deck:
        cmp r10, #0
        ble end_shuffle_deck

        @ generate card
        bl rand
        mov r1, #13
        bl mod

        @ check array for the number of cards
        mov r3, r0, LSL #2
        ldr r2, [sp, r3]
        cmp r2, #4
        bge shuffle_deck

        add r2, r2, #1
        str r2, [sp, r3]

        sub r10, r10, #1

        @ store the card onto the deck
        @ deck array = fp - 8
        ldr r1, [fp, #-8]
        @ldr r1, [r1]
        mov r2, r10, LSL #2

        add r0, r0, #1   @ random # was 0 to 12
        str r0, [r1, r2]

        b shuffle_deck

    end_shuffle_deck:

    sub sp, fp, #4
    pop {fp, pc}

