.cpu cortex-a72
.fpu neon-fp-armv8

.data
outp1: .asciz "Debug\n"
outp2: .asciz "Computer's turn!\n"
outp3: .asciz "Your turn!\n"
humanhand: .asciz "Your Hand: "
card: .asciz "%d "
newline: .asciz "\n"
ask: .asciz "Ask for a number: "
inp: .asciz "%d"
found_card: .asciz "Found\n"
unfound_card: .asciz "Not Found\n"
computer_wants: .asciz "Computer asks for a %d\n"
emptydeck: .asciz "Deck is empty\n"
gofish: .asciz "Go Fish\n"
cardgot: .asciz "%d taken\n"
fishdrawn: .asciz "%d was drawn\n"
.text
.align 2
.global make_move
.type make_move, %function
make_move:

push {fp, lr}
add fp, sp, #4

@r0, holds human hand
@r1, holds computer hand
@r2 holds deck
@r3 holds whos turn
mov r8, r0
mov r9, r1
mov r10, r2

@output Who's move it is
cmp r3, #1
beq computer_turn
human_turn:
ldr r0, =outp3
bl printf

@Procedures
@Print out the human's hand
@Ask for a card to look for
@Check if computer has card and draw if noit

@Printing hand
ldr r0, =humanhand
bl printf

mov r4, #0
mov r5, #0
human_hand_loop:
cmp r4, #47
bge end_human_hand_loop
 
ldr r0, =card
ldr r1, [r8, r5]
cmp r1, #0
beq hop
bl printf
hop:
add r5, r5, #4
add r4, r4, #1
b human_hand_loop
end_human_hand_loop:

ldr r0, =newline
bl printf

@ask for a card to look for
ldr r0, =ask
bl printf

sub sp, sp, #4
mov r1, sp
ldr r0, =inp
bl scanf
ldrb r1, [sp]
@r1 currently holds asked card

mov r4, #0
mov r5, #0
check_if_card_is_same_loop:
cmp r4, #47
bge end_if_card_is_same_loop
ldr r6, [r9, r5]
cmp r6, r1
beq found

add r4, r4, #1
add r5, r5, #4
b check_if_card_is_same_loop

@computer has card
found:
@r1 holds card
mov r0, #0
str r0, [r9, r5]
mov r4, #0
mov r5, #0
found_card_human_hand_place:
cmp r4, #47
beq found_skip
ldr r6, [r8, r5]
cmp r6, #0
beq end_found_card_human_hand_place

add r4, r4, #1
add r5, r5, #4
b found_card_human_hand_place
end_found_card_human_hand_place:
@store the card back into players hand
str r1, [r8, r5]

ldr r0, =cardgot
bl printf
b found_skip


end_if_card_is_same_loop:
@unfound
ldr r0, =gofish
bl printf
@Must go fish and draw a card from the deck
@loop through the deck for the next card
mov r4, #0
mov r5, #0
mov r3, #0
fishing_human_hand_next_card:
cmp r4, #52
bge end_fishing_human_hand_next_card

@ load next card, and check if its a zero
ldr r6, [r10, r5]
cmp r6, #0
beq fishing_zero
mov r3, r6
b end_fishing_human_hand_next_card
fishing_zero:
add r4, r4, #1
add r5, r5, #4
b fishing_human_hand_next_card

@cmp r3, #0
@beq skipping
@mov r4, #0
@str r4, [r10, r5]
@skipping:

end_fishing_human_hand_next_card:

cmp r3, #0
beq skipping
mov r4, #0
str r4, [r10, r5]
skipping:

@r3 holds card or 0 if deck is empty
@loop through player hand to put into their hand

mov r4, #0
mov r5, #0
fishing_player_hand:
cmp r4, #47
beq end_fishing_player_hand

ldr r6, [r8, r5]
cmp r6, #0
beq found_gap

add r4, r4, #1
add r5, r5, #4
b fishing_player_hand
end_fishing_player_hand:
found_gap:
str r3, [r8, r5]

ldr r0, =fishdrawn
mov r1, r3
bl printf

found_skip:
@skip computer turn
b end_of_make_move
computer_turn:
@Randomly generate a card from the computers hand to ask for
@If no such card exists, pick bnetween 1-13 randomly
@Add card to computer hand if player has
@draw from pile if no such card exists



@card for the computer to ask for
bl rand
mov r1, #13
bl mod
add r0, r0, #1

@r0 holds current asked card
mov r4, r0
mov r1, r0
ldr r0, =computer_wants
bl printf

@r1 holds desired card
mov r1, r4
mov r4, #0
mov r5, #0
mov r7, #0
look_in_player_hand_loop:
cmp r4, #47
bge end_look_in_player_hand_loop

ldr r6, [r8, r5]
cmp r6, r1
beq take_card

add r4, r4, #1
add r5, r5, #4
b look_in_player_hand_loop

take_card:
mov r4, #0
str r4, [r8, r5]
mov r7, #1
end_look_in_player_hand_loop:

@card found in players hand
cmp r7, #1
beq found_in_human
cmp r7, #0
beq unfound_in_human
found_in_human:
@loop through computer deck to find next open spot to add card
mov r4, #0
mov r5, #0
adding_card_to_computer_hand_loop:
cmp r4, #47
bge end_adding_card_computer_hand_loop

ldr r6, [r9, r5]
cmp r6, #0
beq add_card

add r4, r4, #1
add r5, r5, #4
b adding_card_to_computer_hand_loop

add_card:
str r1, [r9, r5]
end_adding_card_computer_hand_loop:
b end_of_make_move
unfound_in_human:
ldr r0, =gofish
bl printf

@go thorugh deck to find next card
mov r4, #0
mov r5, #0
mov r6, #0
computer_draw_deck:
cmp r4, #52
bge end_computer_draw_deck

ldr r6, [r10, r5]
cmp r6, #0
bgt end_computer_draw_deck

add r4, r4, #1
add r5, r5, #4
b computer_draw_deck
end_computer_draw_deck:
@r6 holds the card
mov r4, #0
str r4, [r10, r5]
mov r4, #0
mov r5, #0
final_deck_add:
cmp r4, #47
bge end_of_make_move

ldr r1, [r9, r5]
cmp r1, #0
beq end_final_deck_add

add r4, r4, #1
add r5, r5, #4
b final_deck_add
end_final_deck_add:
str r6, [r9, r5]
end_of_make_move:
sub sp, fp, #4
pop {fp, pc}

