.cpu cortex-a53
.fpu neon-fp-armv8


.data

outp:   .asciz  "%d "
outp2: .asciz "\n"


.text
.align 2
.global print_array
.type print_array, %function


print_array:
     push {fp, lr}
     add fp, sp, #4

     @ r0 = address of array, r1 = number of elts in array

     mov r4, r0
     mov r5, r1


     mov r10, #0   @ counter variable

     print_array_loop:

         cmp r10, r5
         bge end_print_array_loop


         @ printf("%d\n", *(r4 + r10*4))

         ldr r0, =outp

         add r1, r4, r10, LSL #2
         ldr r1, [r1]
	 cmp r1, #0
	 beq skip
         bl printf
	 skip:
         add r10, r10, #1
         
         b print_array_loop


     end_print_array_loop:
	ldr r0, =outp2
	bl printf

     sub sp, fp, #4
     pop {fp, pc}

