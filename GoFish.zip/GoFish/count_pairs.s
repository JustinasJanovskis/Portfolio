.cpu cortex-a72
.fpu neon-fp-armv8

.data
outp1: .asciz "Debug: %d"
outp2: .asciz "Pair \n"
.text
.align 2
.global count_pairs
.type count_pairs, %function

count_pairs:
push {fp, lr}
add fp, sp, #4

@Go through the array and remove all pairs
mov r10, r0	@ Player Hand
mov r9, r1	@ Pair location in memory

@loop through all 47 possible cards
@ disregard 0's
mov r4, #0
pair_loop:
cmp r4, #47
bge end_pair_loop
mov r1, #4
mov r5, r4
mul r5, r5, r1

ldr r6, [r10, r5]
cmp r6, #0
beq skip_zero

mov r7, r4
check_loop:
cmp r7, #47
bge end_check_loop
add r7, r7, #1

@multiply r7 by 4
mov r2, #4
mul r2, r2, r7
ldr r8,[r10, r2]
cmp r8, r6
beq pair
b check_loop

pair:

@ldr r0, =outp2
@bl printf

@ldr r1, [r9]
add r9, r9, #1
@str r1, [r9]
mov r3, #0
str r3, [r10, r5]
str r3, [r10, r2]
end_check_loop:
 
skip_zero:
add r4, r4, #1
b pair_loop
end_pair_loop:

@mov r6, r9
@mov r4, #0
@number_of_pairs:
@cmp r4, r6
@bge end_pairs

@ldr r0, =outp2
@bl printf
@add r4, r4, #1
@b number_of_pairs

@end_pairs:

mov r0, r9

sub sp, fp, #4
pop {fp, pc}
