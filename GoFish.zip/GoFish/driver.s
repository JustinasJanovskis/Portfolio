.cpu cortex-a53
.fpu neon-fp-armv8

.data
outp1: .asciz "\nPlayer Hand\n"
outp2: .asciz "\nComputer Hand\n"
outp3: .asciz "Human Pairs: %d\n"
outp4: .asciz "Computer Pairs: %d\n"
newline: .asciz "\n"
.text
.align 2
.global main
.type main, %function



main:

     push {fp, lr}
     add fp, sp, #4

     sub sp, sp, #48   @ store auxiliary data
     sub sp, sp, #208  @ store deck of cards
     str sp, [fp, #-28]
     sub sp, sp, #188
     str sp, [fp, #-20]
     sub sp, sp, #188
     str sp, [fp, #-24]
     sub sp, sp, #4
     str sp, [fp, #-4]
     sub sp, sp, #4
     str sp, [fp, #-8]
     sub sp, sp, #4
     str sp, [fp, #-12]

     @ shuffle the deck
     ldr r0, [fp, #-28]

     bl shuffle

     @ -------------------------------------------------
     @ begin debug
     @ print out deck of cards
     ldr r0, [fp, #-28]
     mov r1, #52
     bl print_array

	@put a 0 into the #of pairs
	mov r6, #0
	str r6, [fp, #-4]
	str r6, [fp, #-8]
	mov r6, #1
	str r6, [fp, #-12]

     @ end debug
     @ -------------------------------------------------
	@fill both player's hands with 0's
	ldr r0, [fp, #-20]
	mov r1, #47
	bl fill_zero
	ldr r0, [fp, #-24]
	mov r1, #47
	bl fill_zero	

	@ deal the cards storing 5 cards in each plyer's hand
	ldr r0, [fp, #-28]
	ldr r1, [fp, #-20]   @player hand
	ldr r2, [fp, #-24]   @ computer hand
	bl dealcards

	ldr r0, [fp, #-20]
	ldr r1, [fp, #-4]
	bl count_pairs
	str r0, [fp, #-4]
	ldr r0, [fp, #-24]
	ldr r1, [fp, #-8]
	bl count_pairs
	str r0, [fp, #-8]
	
	@Debug printing hands
	@ldr r0,=outp1
	@bl printf
	@ldr r0, [fp, #-20]
	@mov r1, #47
	@bl print_array

	@ldr r0, =outp2
	@bl printf
	@ldr r0, [fp, #-24]
	@mov r1, #47
 	@bl print_array
	
	@Start the game loop

	go_fish_game_loop:	

	ldr r0, [fp, #-20]	@ player hand
	ldr r1, [fp, #-24]	@ computer hand
	ldr r2, [fp, #-28]	@ the deck
	ldr r3, [fp, #-12]	@ Who's turn
	bl make_move @making moves

	@Debug printing hands
	@ldr r0,=outp1
	@bl printf
	@ldr r0, [fp, #-20]
	@mov r1, #47
	@bl print_array

	@ldr r0, =outp2
	@bl printf
	@ldr r0, [fp, #-24]
	@mov r1, #47
 	@bl print_array

	ldr r0, [fp, #-20]
	ldr r1, [fp, #-4]
	bl count_pairs
	str r0, [fp, #-4]
	ldr r0, [fp, #-24]
	ldr r1, [fp, #-8]
	bl count_pairs
	str r0, [fp, #-8]
	

	@check if game_over
	ldr r0, [fp, #-28]	@ deck
	ldr r1, [fp, #-20]	@ human hand
	ldr r2, [fp, #-24]	@ computer hand
	bl game_over
	cmp r0, #0
	beq skip

	ldr r0, [fp, #-12]
	add r0, r0, #1
	mov r1, #2
	bl mod
	str r0, [fp, #-12]
	
	ldr r0, =newline
	bl printf

	b go_fish_game_loop
	
	skip:

	ldr r1, [fp, #-4]
	ldr r0, =outp3
	bl printf
	ldr r0, =outp4
	ldr r1, [fp, #-8]
	bl printf

	ldr r0, [fp, #-4]
	ldr r1, [fp, #-8]
	bl print_game

     sub sp, fp, #4
     pop {fp, pc}

