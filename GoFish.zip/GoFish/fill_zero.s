.cpu cortex-a72
.fpu neon-fp-armv8

.data

.text
.align 2
.global fill_zero
.type fill_zero, %function

fill_zero:
push {fp, lr}
add fp, sp, #4

@r4 = array address
@r5 =  number of elts
mov r4,r0
mov r5,r1

mov r10, #0
mov r7, #0
loop:
cmp r10, r5
beq end

mov r6, #0
str r6, [r4]
add r4, r4, #4
add r10, r10, #1
b loop
end:
sub sp, fp, #4
pop {fp, pc}
